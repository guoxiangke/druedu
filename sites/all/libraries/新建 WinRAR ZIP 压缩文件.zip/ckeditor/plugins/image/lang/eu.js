﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'eu', {
	alertUrl: 'Mesedez Irudiaren URLa idatzi',
	alt: 'Ordezko Testua',
	border: 'Ertza',
	btnUpload: 'Zerbitzarira bidalia',
	button2Img: 'Aukeratutako irudi botoia, irudi normal batean eraldatu nahi duzu?',
	hSpace: 'HSpace',
	img2Button: 'Aukeratutako irudia, irudi botoi batean eraldatu nahi duzu?',
	infoTab: 'Irudi informazioa',
	linkTab: 'Esteka',
	lockRatio: 'Erlazioa Blokeatu',
	menu: 'Irudi Ezaugarriak',
	resetSize: 'Tamaina Berrezarri',
	title: 'Irudi Ezaugarriak',
	titleButton: 'Irudi Botoiaren Ezaugarriak',
	upload: 'Gora Kargatu',
	urlMissing: 'Image source URL is missing.', // MISSING
	vSpace: 'VSpace',
	validateBorder: 'Border must be a whole number.', // MISSING
	validateHSpace: 'HSpace must be a whole number.', // MISSING
	validateVSpace: 'VSpace must be a whole number.' // MISSING
});
