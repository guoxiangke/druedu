﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'fr', {
	alertUrl: 'Veuillez entrer l\'adresse de l\'image',
	alt: 'Texte de remplacement',
	border: 'Bordure',
	btnUpload: 'Envoyer sur le serveur',
	button2Img: 'Voulez-vous transformer le bouton image sélectionné en simple image?',
	hSpace: 'Espacement horizontal',
	img2Button: 'Voulez-vous transformer l\'image en bouton image?',
	infoTab: 'Informations sur l\'image',
	linkTab: 'Lien',
	lockRatio: 'Conserver les proportions',
	menu: 'Propriétés de l\'image',
	resetSize: 'Taille d\'origine',
	title: 'Propriétés de l\'image',
	titleButton: 'Propriétés du bouton image',
	upload: 'Envoyer',
	urlMissing: 'L\'adresse source de l\'image est manquante.',
	vSpace: 'Espacement vertical',
	validateBorder: 'Bordure doit être un entier.',
	validateHSpace: 'HSpace doit être un entier.',
	validateVSpace: 'VSpace doit être un entier.'
});
